// Your web app's Firebase configuration
var firebaseConfig = {
    apiKey: "AIzaSyC3CwvJMmfPOx4Ufi9QQuni-xqvTnr7xUs",
    authDomain: "project-quiz-app-d0f82.firebaseapp.com",
    databaseURL: "https://project-quiz-app-d0f82-default-rtdb.firebaseio.com",
    projectId: "project-quiz-app-d0f82",
    storageBucket: "project-quiz-app-d0f82.appspot.com",
    messagingSenderId: "70402960210",
    appId: "1:70402960210:web:a455a43310932bb6e3a88b"
  };
  
  // Initialize Firebase
  var app = firebase.initializeApp(firebaseConfig);
//   console.log(app.database);

var questions = [
    {
        question:"Q1: Who invented JavaScript?",
        option1:"Douglas Crockford",
        option2:"Guido van Rossum",
        option3:"Brendan Eich",
        correctAns:"Brendan Eich"
    },
    {
        question:"Q2: Which one of these is a JavaScript package manager?",
        option1:"Node.js",
        option2:"npm",
        option3:"TypeScript",
        correctAns:"npm"
    },{
        question:"Q3: Which tool can you use to ensure code quality?",
        option1:"Angular",
        option2:"ESLint",
        option3:"jQuery",
        correctAns:"ESLint"
    },{
        question:"Q4: Which tag gives your the largest heading in html?",
        option1:"<h6>",
        option2:"<h2>",
        option3:"<h1>",
        correctAns:"<h1>"
    },{
        question:"Q5: how many data types in js?",
        option1:"6",
        option2:"7",
        option3:"8",
        correctAns:"8"
    },{
        question:"Q6: HTML stands for?",
        option1:"Hyper Text markup language",
        option2:"Hyper Link markup language",
        option3:"Hyper Text makeup language",
        correctAns:"Hyper Text markup language"
    }
    ,{
        question:"Q7: how many days in febuary?",
        option1:"30",
        option2:"28",
        option3:"29",
        correctAns:"28"
  }];
  
  
  var para = document.getElementById("ques");
  var opt1 = document.getElementById("opt1");
  var opt2 = document.getElementById("opt2");
  var opt3 = document.getElementById("opt3");
  var button = document.getElementById("btn");
  var timer = document.getElementById("timer")
  var index = 0;
  var score = 0;
  var min = 1;
  var sec = 59;
  
  
  
  setInterval(function(){
      timer.innerHTML = `${min}:${sec}`;
      sec--
      if(sec<0){
          min--;
          sec = 59    
      }
      if(min<0){
          min= 1;
          sec = 59;
          nextQuestion()
      }
  },100)
  
  
  function nextQuestion(){
  
      var getOptions = document.getElementsByName("options");
  
      for(var i = 0;i<getOptions.length;i++)
      {
          if(getOptions[i].checked){
              var selectedValue = getOptions[i].value;
              // console.log(selectedValue)
              var selectedQues = questions[index - 1]["question"];
              var selectedAns = questions[index-1][`option${selectedValue}`]
              var correctAns = questions[index - 1]["correctAns"]
              if(selectedAns == correctAns){
                  score++
              }
              var database = firebase.database().ref("QUIZ APP/Answer/");
              var key = database.push().key;
              var quizAnswer = {
                question: questions[index - 1].question,
                selectedOption: selectedValue,
                selectedAnswer: selectedAns,
                correctAnswer: correctAns,
              }
               database.push(quizAnswer);
          }
          getOptions[i].checked = false
      }
      button.disabled = true
  
      if(index >questions.length - 1){
  
          Swal.fire(
              'Good job!',
          `Your percentage is ${((score / questions.length)*100).toFixed(2)}`,
              'success'
            )
          // console.log("your percentage is " + ((score / questions.length)*100).toFixed(2))
      }
      else{
  
  
          para.innerHTML = questions[index].question;
          opt1.innerText = questions[index].option1;
          opt2.innerText = questions[index].option2;
          opt3.innerText = questions[index].option3;
          index++
      }
  }
  
  // nextQuestion()
  function getDataDB(){
    firebase
      .database()
      .ref("QUIZ APP/Answer/")
      .on("value", function(data) {
        console.log(data.val());
      });
  }
  getDataDB();
  
  function clicked()
  {
      button.disabled = false
  }